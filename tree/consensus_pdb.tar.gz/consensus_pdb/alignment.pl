use strict;
use warnings;

my $output = "output.txt";
if (!-e $output) {
    open my $fh, '>', $output or die "Could not open file '$output' $!";
    close $fh;
}

open my $fh, '>>', $output or die "Could not open file '$output' $!";
my @files = glob("*.pdb");
push @files, glob("*.cif");

for my $file1 (@files) {
    for my $file2 (@files){
        if ($file1 ne $file2) {
            print("Comparing $file1 and $file2\n");
            print $fh `TMalign $file1 $file2`;
        }
    }
}

# for my $file (@files) {
    # `gzip $file`;
# }
# close $fh;

open my $fh2, '<', "temp.txt"or die "Can't open file: $!";
while(my $line = <$fh2>) {
    chomp $line;
    if ($line =~ m/^(Name|Length|Aligned|TM-score)/) {
        print("$line\n");
    }
}
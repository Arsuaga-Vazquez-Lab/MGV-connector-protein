v
# for my $file (@files) {
    # `gzip $file`;
# }


open my $wh, '>>', $output or die "Could not open file '$output' $!";
open my $fh, '<', $temp or die "Can't open file: $!";
while(my $line = <$fh>) {
    chomp $line;
    if ($line =~ m/^(Name|Length|Aligned|TM-score)/) {
        # print("$line\n", $wh);
		print $wh "$line\n";
    }
}
close $fh;
close $wh;